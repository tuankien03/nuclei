import { TemplatesScriptData } from "./../types/index";

export const templatesScriptData: TemplatesScriptData = (window as any)
	.evf_templates_script;
