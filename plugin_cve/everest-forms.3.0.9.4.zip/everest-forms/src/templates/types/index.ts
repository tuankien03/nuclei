export type TemplatesScriptData = {
	security: string;
	restURL: string;
};
