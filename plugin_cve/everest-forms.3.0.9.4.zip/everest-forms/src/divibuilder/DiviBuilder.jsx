// External Dependencies
import React, { Component} from 'react';

class DiviBuilder extends Component {

  static slug = 'everest_forms_divi_builder';
  render() {
    return (
		<div className='everest-forms-divi-builder'></div>
    );
  }
}

export default DiviBuilder; 
