import React from "react";

import DiviBuilder from "./DiviBuilder";

const App = () => {
	return (
		<DiviBuilder/>
	);
};

export default App;
