import registerBlocks from "./blocks";

//Register the blocks.
registerBlocks();
