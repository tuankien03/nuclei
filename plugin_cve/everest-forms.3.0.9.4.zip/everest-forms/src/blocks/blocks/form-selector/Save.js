import React from 'react'

const Save = () => {
  return null
}

export default Save
