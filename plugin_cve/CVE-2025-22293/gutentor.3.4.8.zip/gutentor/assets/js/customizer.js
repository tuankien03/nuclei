wp.customize.selectiveRefresh.bind( 'partial-content-rendered', function( placement ) {
    // console.log(placement)
    /*TODO*/
} );