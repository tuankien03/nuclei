<?php
require_once __DIR__ . '/safari.php';
require_once __DIR__ . '/wp-compose-js.php';
