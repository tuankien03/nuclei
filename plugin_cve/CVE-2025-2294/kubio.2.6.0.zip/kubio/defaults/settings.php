<?php

return array(
	'googleFonts' => array(
		'serveLocally' => false,
	),
);
