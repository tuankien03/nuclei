<?php

namespace Kubio\Core\Blocks;

class BlockStyle {


}
