<?php

require_once __DIR__ . '/contact-form/index.php';
require_once __DIR__ . '/subscribe-form/subscribe-form.php';
