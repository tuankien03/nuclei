<?php

namespace Kubio\Core;

class InnerBlocks {
	function __construct( $separators ) {}
	function __toString() {
		 return '<InnerBlocks/>';
	}
}

