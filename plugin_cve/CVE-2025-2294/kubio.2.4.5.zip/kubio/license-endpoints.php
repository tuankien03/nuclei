<?php

return array(
	'license_active_endpoint' => 'https://cloud.kubiobuilder.com/api/license/activate',
	'license_check_endpoint'  => 'https://cloud.kubiobuilder.com/api/license/check',
	'dashboard_url'           => 'https://cloud.kubiobuilder.com/',
	'product_update_endpoint' => 'https://cloud.kubiobuilder.com/api/product/update',
);
